//
//  SendAndScanVC.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit

class SendAndScanVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func onBtnClose(_ sender: Any) {
        self.popVC()
    }
}
