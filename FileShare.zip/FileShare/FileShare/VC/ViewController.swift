//
//  ViewController.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit

struct MediaType {
    let title: String
    let image: UIImage?
}

class ViewController: UIViewController {

    
    @IBOutlet weak var clvMediaTypes: UICollectionView!
    @IBOutlet weak var viewTab: UIView!
    
    private var pageViewController: UIPageViewController!
    private var selectedIndex = 0

    // Data source for collection view
    let mediaTypes = [
        MediaType(title: "Image", image: UIImage(named: "imageIcon")),
        MediaType(title: "Videos", image: UIImage(named: "videoIcon")),
        MediaType(title: "Contacts", image: UIImage(named: "contactsIcon")),
        MediaType(title: "Music", image: UIImage(named: "musicIcon")),
        MediaType(title: "Files", image: UIImage(named: "filesIcon"))
    ]
    
    private lazy var categoryViewControllers: [UIViewController] = {
        return [
            ImageVC.fromStoryboard(.Main),
            VideosVC.fromStoryboard(.Main),
            ContactsVC.fromStoryboard(.Main),
            MusicVC.fromStoryboard(.Main),
            FilesVC.fromStoryboard(.Main)
        ]
    }()


    override func viewDidLoad() {
        super.viewDidLoad()
        setupClv()
        setupPageViewController()
    }
    
    func setupClv() {
        clvMediaTypes.dataSource = self
        clvMediaTypes.delegate = self
        
        // Register the cell
        clvMediaTypes.register(UINib(nibName: "MediaTypeCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "MediaTypeCell")
        
        // Set up layout
        if let layout = clvMediaTypes.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
            layout.minimumLineSpacing = 15
            layout.minimumInteritemSpacing = 15
        }
    }

    func setupPageViewController() {
        // Initialize and configure the UIPageViewController
        pageViewController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageViewController.dataSource = self
        pageViewController.delegate = self
        
        // Set initial view controller
        pageViewController.setViewControllers([categoryViewControllers[selectedIndex]], direction: .forward, animated: true, completion: nil)
        pageViewController.view.backgroundColor = .clear
        // Add pageViewController as a child
        addChild(pageViewController)
        view.addSubview(pageViewController.view)
        
        // Set up page view controller constraints
        pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            pageViewController.view.topAnchor.constraint(equalTo: clvMediaTypes.bottomAnchor, constant: 10),
            pageViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pageViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            pageViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        pageViewController.didMove(toParent: self)
        
        view.bringSubviewToFront(viewTab)
    }

    @IBAction func onBtnSend(_ sender: Any) {
        let vc = SendAndScanVC.fromStoryboard(.Main)
        self.pushVC(vc)
    }
    
    @IBAction func onBtnReceive(_ sender: Any) {
    }
    
}


extension ViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    // MARK: - UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mediaTypes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MediaTypeCell", for: indexPath) as! MediaTypeCollectionViewCell
        cell.configure(with: mediaTypes[indexPath.item])
        // Change the title color based on whether the cell is selected
        if indexPath.row == selectedIndex {
             // Change the color of the selected title
            cell.viewMain.layer.borderColor = UIColor.white.cgColor
            cell.titleLabel.textColor = .white
        } else {
            cell.viewMain.layer.borderColor = UIColor.white.withAlphaComponent(0.4).cgColor
            cell.titleLabel.textColor = .white.withAlphaComponent(0.7)

        }
        return cell
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Calculate width based on title and image size
        let mediaType = mediaTypes[indexPath.item]
        
        // Set cell height to fixed value, width based on text and image
        let cellHeight: CGFloat = 40
        let padding: CGFloat = 15 // 10 padding left and right
        let titleWidth = mediaType.title.size(withAttributes: [.font: UIFont.systemFont(ofSize: 15, weight: .bold)]).width
        let imageWidth: CGFloat = 40 // Adjust to image width

        // Total cell width with padding
        let cellWidth = imageWidth + titleWidth + padding
        return CGSize(width: cellWidth, height: cellHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Update selected index and display the corresponding view controller
        let selectedVC = categoryViewControllers[indexPath.item]
        let direction: UIPageViewController.NavigationDirection = indexPath.item > selectedIndex ? .forward : .reverse
        pageViewController.setViewControllers([selectedVC], direction: direction, animated: true, completion: nil)
        // Update the selected index
        selectedIndex = indexPath.item
        // Reload collection view to update the selection style
        clvMediaTypes.reloadData()
        // Scroll to the selected item in collection view
        clvMediaTypes.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
}

// MARK: - UIPageViewController Data Source and Delegate

extension ViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let index = categoryViewControllers.firstIndex(of: viewController), index > 0 else {
            return nil
        }
        return categoryViewControllers[index - 1]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let index = categoryViewControllers.firstIndex(of: viewController), index < categoryViewControllers.count - 1 else {
            return nil
        }
        return categoryViewControllers[index + 1]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed, let visibleViewController = pageViewController.viewControllers?.first, let index = categoryViewControllers.firstIndex(of: visibleViewController) {
            selectedIndex = index
            clvMediaTypes.selectItem(at: IndexPath(item: selectedIndex, section: 0), animated: true, scrollPosition: .centeredHorizontally)
            clvMediaTypes.reloadData()
        }
    }

}
