//
//  ImageVC.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit
import Photos

class ImageVC: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!

    private var images: [PHAsset] = []
    private var groupedImages: [String: [PHAsset]] = [:]  // Grouped by date (Today, Yesterday, Specific Dates)
    private var selectedImages: Set<PHAsset> = [] // Track selected images
    var sortedKeys = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        collectionView.dataSource = self
        collectionView.delegate = self

        // Register custom cells
        collectionView.register(UINib(nibName: "ImageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ImageCollectionViewCell")
        collectionView.register(UINib(nibName: "SectionHeaderCell", bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "SectionHeaderCell")

        requestPhotoLibraryPermission()
    }

    // Request permission to access Photos library
    func requestPhotoLibraryPermission() {
        PHPhotoLibrary.requestAuthorization { status in
            switch status {
            case .authorized:
                self.loadImages()
            case .denied, .restricted:
                print("Access to photos denied.")
            default:
                break
            }
        }
    }

    // Load images and group them by date
    func loadImages() {
        let fetchOptions = PHFetchOptions()
        fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]

        let assets = PHAsset.fetchAssets(with: .image, options: fetchOptions)

        assets.enumerateObjects { (asset, index, stop) in
            guard let creationDate = asset.creationDate else { return }

            let dateString = self.getFormattedDate(for: creationDate)
            
            if self.groupedImages[dateString] == nil {
                self.groupedImages[dateString] = []
            }
            self.groupedImages[dateString]?.append(asset)
        }

        // Sort the groupedImages keys (dates) by actual Date objects, not lexicographically
        let sortedKey = self.groupedImages.keys.sorted { dateString1, dateString2 in
            guard let date1 = self.getDate(from: dateString1),
                  let date2 = self.getDate(from: dateString2) else { return false }
            return date1 > date2  // Sort in descending order (newest first)
        }
        sortedKeys = sortedKey
        print(sortedKeys)
        
        self.images = assets.objects(at: IndexSet(0..<assets.count))
        runMain {
            self.collectionView.reloadData()
        }
        
    }
    
    // Helper to convert date string back to Date for comparison
    func getDate(from string: String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: string)
    }
    
    func getFormattedDate(for date: Date) -> String {
        let calendar = Calendar.current
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    // Select or deselect all items in a section
    func selectDeselectAllItems(in section: Int) {
        let dateKey = Array(groupedImages.keys)[section]
        let assets = groupedImages[dateKey] ?? []
        
        if selectedImages.isSuperset(of: Set(assets)) {
            // Deselect all
            selectedImages.subtract(assets)
        } else {
            // Select all
            selectedImages.formUnion(assets)
        }

        collectionView.reloadSections([section])  // Reload the section to update the selection
    }

    // Toggle selection of an individual image
    func toggleSelection(for asset: PHAsset) {
        if selectedImages.contains(asset) {
            selectedImages.remove(asset)
        } else {
            selectedImages.insert(asset)
        }
        runMain {
            self.collectionView.reloadData()
        }
    }
}

// MARK: - UICollectionViewDataSource
extension ImageVC: UICollectionViewDataSource {

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return groupedImages.count
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let dateKey = Array(groupedImages.keys)[section]
        return groupedImages[dateKey]?.count ?? 0
    }

    // Cell for images
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let dateKey = Array(groupedImages.keys)[indexPath.section]
        let asset = groupedImages[dateKey]?[indexPath.item]
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath) as! ImageCollectionViewCell

        // Fetch image thumbnail
        PHImageManager.default().requestImage(for: asset!, targetSize: CGSize(width: 100, height: 100), contentMode: .aspectFill, options: nil) { (image, _) in
            cell.imageView.image = image
        }

        // Update the selection icon state
        cell.selectionIcon.isSelected = selectedImages.contains(asset!)

        return cell
    }

    // Section Header for date titles (Today, Yesterday, etc.)
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "SectionHeaderCell", for: indexPath) as! SectionHeaderCell
        
        let dateKey = Array(groupedImages.keys)[indexPath.section]
        headerView.dateLabel.text = dateKey
        headerView.selectButton.tag = indexPath.section
        headerView.selectButton.addTarget(self, action: #selector(selectAllInSection(_:)), for: .touchUpInside)
        
        return headerView
    }
    
    @objc func selectAllInSection(_ sender: UIButton) {
        selectDeselectAllItems(in: sender.tag)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension ImageVC: UICollectionViewDelegateFlowLayout {

    // Set the size for the image cells
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Define the number of items per row (4 items in this case)
        let itemsPerRow: CGFloat = 4
        
        // Calculate the width of each item based on the collection view's width
        let padding: CGFloat = 10 // Define padding between cells
        let totalSpacing = padding * (itemsPerRow + 1) // 4 cells + 3 gaps
        let availableWidth = collectionView.frame.width - totalSpacing
        let itemWidth = availableWidth / itemsPerRow
        
        // Return the calculated width and a fixed height (you can adjust the height as needed)
        return CGSize(width: round(itemWidth) , height: round(itemWidth))
    }

    // Set the size for the section header
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 50)
    }
}


