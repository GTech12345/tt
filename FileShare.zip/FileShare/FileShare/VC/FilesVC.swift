//
//  FilesVC.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//
import UIKit


class FilesVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
