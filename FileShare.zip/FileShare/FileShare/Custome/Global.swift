//
//  File.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//
import Foundation

func delay(time: Double, closure: @escaping ()->()) {
    DispatchQueue.main.asyncAfter(deadline: .now() + time) {
        closure()
    }
}

func runMain(closure: @escaping ()->()) {
    DispatchQueue.main.async {
        closure()
    }
}
