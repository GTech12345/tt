//
//  Ext.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import Foundation
import UIKit


extension UIViewController {
    
    // MARK: - Push ViewController
    func pushVC(_ viewController: UIViewController, animated: Bool = true) {
        self.navigationController?.pushViewController(viewController, animated: animated)
    }
    
    // MARK: - Pop ViewController
    func popVC(animated: Bool = true) {
        self.navigationController?.popViewController(animated: animated)
    }
    
    // MARK: - Pop to Root ViewController
    func popToRootVC(animated: Bool = true) {
        self.navigationController?.popToRootViewController(animated: animated)
    }
    
    // MARK: - Pop to a Specific ViewController
    func popToVC(ofType vcType: UIViewController.Type, animated: Bool = true) {
        if let viewControllers = self.navigationController?.viewControllers {
            for vc in viewControllers {
                if vc.isKind(of: vcType) {
                    self.navigationController?.popToViewController(vc, animated: animated)
                    break
                }
            }
        }
    }
}

