//
//  CustomUIView.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//


import UIKit

@IBDesignable // Allows you to preview the view in Interface Builder
class CustomUIView: UIView {

    // MARK: - IBInspectable properties to customize in Storyboard
    @IBInspectable var borderWidth: CGFloat = 1 {
        didSet {
            setupView()
        }
    }
    
    @IBInspectable var borderColor: UIColor = .black {
        didSet {
            setupView()
        }
    }
    
    @IBInspectable var backgroundColorCustom: UIColor = .clear {
        didSet {
            setupView()
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }

    private func setupView() {
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = borderColor.cgColor
        self.backgroundColor = backgroundColorCustom
        self.layer.cornerRadius = 8 // Optional: You can add corner radius if needed
    }

}
