//
//  MediaTypeCollectionViewCell.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit

class MediaTypeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewMain.layer.borderColor = UIColor.white.withAlphaComponent(0.4).cgColor
        viewMain.layer.borderWidth = 1.5
        viewMain.layer.cornerRadius = 8
    }
    
    func configure(with mediaType: MediaType) {
        imageView.image = mediaType.image
        titleLabel.text = mediaType.title
        
    }
}
