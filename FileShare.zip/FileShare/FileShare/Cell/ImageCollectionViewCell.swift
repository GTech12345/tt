//
//  ImageCollectionViewCell.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit
import Photos

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var selectionIcon: UIButton!  // Button to indicate selected state
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Set the default selection icon state
        selectionIcon.isSelected = false
    }
    
    // Configure the cell with the image and selection state
    func configure(with asset: PHAsset) {
        // You can fetch and display the image here if necessary
        
        // Update the selection icon
        selectionIcon.isSelected = false // or set to the actual selected state
    }
}
