//
//  SectionHeaderCell.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit

class SectionHeaderCell: UICollectionViewCell {
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var selectButton: UIButton! // Button to select/deselect all items in the section
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func toggleSelectAll(_ sender: UIButton) {
        // Call the parent view controller to select/deselect all items in the section
    }
}
