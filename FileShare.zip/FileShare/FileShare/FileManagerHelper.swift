//
//  FileManagerHelper.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//


import Foundation

class FileManagerHelper {
    
    // MARK: - Folder Names Enum
    enum FolderName: String {
        case files = "Files"
    }
    
    // MARK: - Properties
    private let fileManager = FileManager.default
    private var documentsURL: URL {
        return fileManager.urls(for: .libraryDirectory, in: .userDomainMask)[0]
    }
    
    // MARK: - Folder Operations
    
    /// Creates a folder in the Documents directory if it doesn't already exist
    /// - Parameter folder: Enum value for the folder to be created
    /// - Returns: URL of the created or existing folder, or nil if an error occurred
    func createFolder(_ folder: FolderName) -> URL? {
        let folderURL = documentsURL.appendingPathComponent(folder.rawValue)
        
        // Check if the folder already exists
        if fileManager.fileExists(atPath: folderURL.path) {
            print("Folder \(folder.rawValue) already exists.")
            return folderURL
        }
        
        do {
            try fileManager.createDirectory(at: folderURL, withIntermediateDirectories: true, attributes: nil)
            return folderURL
        } catch {
            print("Failed to create folder \(folder.rawValue): \(error.localizedDescription)")
            return nil
        }
    }
    
    // MARK: - File Operations
    
    /// Adds a file to a specified folder, overwriting if it already exists
    /// - Parameters:
    ///   - fileName: Name of the file to be created
    ///   - folder: Enum value for the folder where the file will be stored
    ///   - data: Data to write to the file
    /// - Returns: URL of the created or updated file, or nil if an error occurred
    func addFile(named fileName: String, inFolder folder: FolderName, withData data: Data) -> URL? {
        let folderURL = documentsURL.appendingPathComponent(folder.rawValue)
        
        // Create folder if it doesn't exist
        if !fileManager.fileExists(atPath: folderURL.path) {
            _ = createFolder(folder)
        }
        
        let fileURL = folderURL.appendingPathComponent(fileName)
        
        do {
            // Overwrite the file if it already exists
            try data.write(to: fileURL, options: .atomic)
            print("File \(fileName) was created or updated at \(fileURL.path).")
            return fileURL
        } catch {
            print("Failed to write file \(fileName): \(error.localizedDescription)")
            return nil
        }
    }
    
    /// Lists all files in a specified folder
    /// - Parameter folder: Enum value for the folder to list files from
    /// - Returns: Array of file URLs or an empty array if the folder doesn't exist or an error occurred
    func listFiles(inFolder folder: FolderName) -> [URL] {
        let folderURL = documentsURL.appendingPathComponent(folder.rawValue)
        
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: folderURL, includingPropertiesForKeys: nil)
            return fileURLs
        } catch {
            print("Failed to list files in folder \(folder.rawValue): \(error.localizedDescription)")
            return []
        }
    }
    
    /// Deletes a file
    /// - Parameter fileURL: URL of the file to be deleted
    func deleteFile(at fileURL: URL) {
        if fileManager.fileExists(atPath: fileURL.path) {
            do {
                try fileManager.removeItem(at: fileURL)
                print("File deleted at \(fileURL.path).")
            } catch {
                print("Failed to delete file: \(error.localizedDescription)")
            }
        } else {
            print("File does not exist at \(fileURL.path).")
        }
    }
    
    /// Deletes a folder and all its contents
    /// - Parameter folder: Enum value for the folder to be deleted
    func deleteFolder(_ folder: FolderName) {
        let folderURL = documentsURL.appendingPathComponent(folder.rawValue)
        
        if fileManager.fileExists(atPath: folderURL.path) {
            do {
                try fileManager.removeItem(at: folderURL)
                print("Folder \(folder.rawValue) deleted.")
            } catch {
                print("Failed to delete folder \(folder.rawValue): \(error.localizedDescription)")
            }
        } else {
            print("Folder \(folder.rawValue) does not exist.")
        }
    }
}
