//
//  StoryboardName.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//
import UIKit

extension UIViewController {
    
    enum StoryboardName: String {
        case Main = "Main"
    }
    static func fromStoryboard(_ storyboardName: StoryboardName) -> Self {
        let storyboard = UIStoryboard(name: storyboardName.rawValue, bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: String(describing: self)) as! Self
    }
}
