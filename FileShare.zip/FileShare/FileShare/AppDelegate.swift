//
//  AppDelegate.swift
//  FileShare
//
//  Created by Milan B. Savaliya on 13/11/24.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        gotoHome()
        return true
    }

    func gotoHome() {
        let tabBarVC = ViewController.fromStoryboard(.Main)
        let navigationController = UINavigationController(rootViewController: tabBarVC)
        navigationController.isNavigationBarHidden = true
        
        // Perform the transition with animation
        UIView.transition(with: window!,
                          duration: 0.3,
                          options: .transitionCrossDissolve,
                          animations: {
            self.window!.rootViewController = navigationController
                          },
                          completion: nil)

        window!.makeKeyAndVisible()
    }

}

