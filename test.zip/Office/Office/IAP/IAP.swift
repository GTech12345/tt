import Foundation
import StoreKit
import SwiftyStoreKit

class IAPHelper {

    // Shared instance (Singleton pattern)
    static let shared = IAPHelper()

    // Product Identifiers for your app's subscriptions
    let subscriptionProductIDs: Set<String> = [
       "fonts.Keyboard.cool.font.for.iphone.weekly",
       "fonts.Keyboard.cool.font.for.iphone.yearly"
    ]
    
    var products: [SKProduct] = []
    var receiptInfo: ReceiptInfo?

    // MARK: - Fetch Available Products
    /// Fetches product information from the App Store.
    func fetchProducts(completion: @escaping (Result<[SKProduct], Error>) -> Void) {
        SwiftyStoreKit.retrieveProductsInfo(subscriptionProductIDs) { result in
            if let error = result.error {
                self.logError(error)
                completion(.failure(error))
            } else {
                self.products = Array(result.retrievedProducts)
                completion(.success(self.products))
            }
        }
    }

    // MARK: - Get Subscription Plans
    /// Retrieves subscription plans from the available products.
    func getSubscriptionPlans(completion: @escaping ([SubscriptionPlan]) -> Void) {
        fetchProducts { result in
            switch result {
            case .success(let products):
                let plans = products.map { self.createSubscriptionPlan(from: $0) }
                completion(plans)
            case .failure(let error):
                self.logError(error)
                completion([])
            }
        }
    }

    // MARK: - Purchase Product
    /// Initiates the purchase of a product.
    func purchaseProduct(productId: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        SwiftyStoreKit.purchaseProduct(productId, atomically: true) { result in
            switch result {
            case .success(let purchase):
                if purchase.needsFinishTransaction {
                    SwiftyStoreKit.finishTransaction(purchase.transaction)
                }
                completion(.success(true))
            case .error(let error):
                self.logError(error)
                completion(.failure(error))
            }
        }
    }

    // MARK: - Restore Purchases
    /// Restores previous purchases.
    func restorePurchases(completion: @escaping (Bool) -> Void) {
        SwiftyStoreKit.restorePurchases { results in
            if results.restoreFailedPurchases.count > 0 {
                print("Restore Failed: \(results.restoreFailedPurchases)")
                completion(false)
            } else if results.restoredPurchases.count > 0 {
                print("Restore Success: \(results.restoredPurchases)")
                completion(true)
            } else {
                print("Nothing to Restore")
                completion(false)
            }
        }
    }

    // Helper method to get product by identifier
    func getProduct(withIdentifier identifier: String) -> SKProduct? {
        return products.first(where: { $0.productIdentifier == identifier })
    }
    
    // MARK: - Validate Receipt
    /// Validates the receipt with Apple's servers.
    func validateReceipt(completion: @escaping (Result<ReceiptInfo, Error>) -> Void) {
#if DEBUG
        // font 
        let appleValidator = AppleReceiptValidator(service: .sandbox, sharedSecret: "6a4d9038ede04caca568d87466e39f36") // Use sandbox for testing
#else
        let appleValidator = AppleReceiptValidator(service: .production, sharedSecret: "7ec737efe3234381ab025d1a8c551b1a") // Use production for live
#endif
        
        SwiftyStoreKit.verifyReceipt(using: appleValidator) { result in
            switch result {
            case .success(let receipt):
                self.receiptInfo = receipt
                completion(.success(receipt))
            case .error(let error):
                self.logError(error)
                completion(.failure(error))
            }
        }
    }

    // MARK: - Check Subscription Status
    /// Checks whether the subscription is active or expired.
    func isSubscriptionActive(for productId: String, receipt: ReceiptInfo) -> Bool {
        let purchaseResult = SwiftyStoreKit.verifySubscriptions(productIds: [productId], inReceipt: receipt)
        
        switch purchaseResult {
        case .purchased(let expiryDate, _):
            return expiryDate > Date()
        case .expired(_, _):
            return false
        case .notPurchased:
            return false
        }
    }

    // MARK: - Check if Free Trial is Active
    /// Checks if the user is currently in a free trial for a specific product.
    func isFreeTrialActive(for productId: String, receipt: ReceiptInfo) -> Bool {
        let purchaseResult = SwiftyStoreKit.verifySubscriptions(productIds: [productId], inReceipt: receipt)
        
        switch purchaseResult {
        case .purchased(let expiryDate, let items):
            print(expiryDate)
            if let mostRecent = items.first {
                return mostRecent.isTrialPeriod
            }
            return false
        case .expired(let expiryDate, let items):
            print(expiryDate)
            print(items)
            return false
        case .notPurchased:
            return false
        }
    }

    // MARK: - Helper to Create Subscription Plan
    /// Creates a SubscriptionPlan object from a product.
    private func createSubscriptionPlan(from product: SKProduct) -> SubscriptionPlan {
        let isFreeTrial = product.introductoryPrice != nil
        let formattedPrice = formatPrice(for: product)
        
        var trialDescription = ""
        if let introductoryPrice = product.introductoryPrice {
            switch introductoryPrice.subscriptionPeriod.unit {
            case .day:
                trialDescription = "\(introductoryPrice.subscriptionPeriod.numberOfUnits) day\(introductoryPrice.subscriptionPeriod.numberOfUnits > 1 ? "s" : "") free trial"
            case .week:
                trialDescription = "\(introductoryPrice.subscriptionPeriod.numberOfUnits) week\(introductoryPrice.subscriptionPeriod.numberOfUnits > 1 ? "s" : "") free trial"
            case .month:
                trialDescription = "\(introductoryPrice.subscriptionPeriod.numberOfUnits) month\(introductoryPrice.subscriptionPeriod.numberOfUnits > 1 ? "s" : "") free trial"
            case .year:
                trialDescription = "\(introductoryPrice.subscriptionPeriod.numberOfUnits) year\(introductoryPrice.subscriptionPeriod.numberOfUnits > 1 ? "s" : "") free trial"
            default:
                trialDescription = introductoryPrice.localizedPrice ?? ""
            }
        }
        
        return SubscriptionPlan(
            productId: product.productIdentifier,
            title: product.localizedTitle,
            price: formattedPrice,
            isFreeTrialAvailable: isFreeTrial,
            trialDescription: trialDescription
        )
    }

    // MARK: - Helper to Format Product Price
    /// Formats the price of the product.
    private func formatPrice(for product: SKProduct) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = product.priceLocale
        return formatter.string(from: product.price) ?? "\(product.price)"
    }

    // MARK: - Centralized Error Logging
    /// Centralized error logging function.
    private func logError(_ error: Error) {
        // Use an external service like Firebase Crashlytics or Sentry for logging in production
        print("Error: \(error.localizedDescription)")
    }
}

// MARK: - Subscription Plan Model
/// Model for representing a subscription plan.
struct SubscriptionPlan {
    let productId: String
    let title: String
    let price: String
    let isFreeTrialAvailable: Bool
    let trialDescription: String
}
