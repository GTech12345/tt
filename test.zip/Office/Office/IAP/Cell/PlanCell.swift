//
//  PlanCell.swift
//  Office
//
//  Created by Milan B. Savaliya on 25/09/24.
//

import UIKit

class PlanCell: UITableViewCell {

    @IBOutlet weak var planTitle: UILabel!
    @IBOutlet weak var planPrice: UILabel!
    @IBOutlet weak var lblFreeTrialDays: UILabel!
    @IBOutlet weak var planId: UILabel!
    @IBOutlet weak var isFreeTrialAvailabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    
}
