//
//  ViewController.swift
//  Office
//
//  Created by Milan B. Savaliya on 19/09/24.
//

import UIKit

class ViewController: UIViewController {
        
    @IBOutlet weak var stkSalary: UIStackView!
    @IBOutlet weak var stkDailyWorkingHours: UIStackView!
    @IBOutlet weak var stkDays: UIStackView!
    
    @IBOutlet weak var txtSalary: UITextField!
    @IBOutlet weak var txtDailyWorkingHours: UITextField!
    @IBOutlet weak var txtDaysInThisMonth: UITextField!
    @IBOutlet weak var txtWorksDays: UITextField!
    
    @IBOutlet weak var lblPerDaySalary: UILabel!
    @IBOutlet weak var lblPerHourSalary: UILabel!
    @IBOutlet weak var lblPerMinSalary: UILabel!
    @IBOutlet weak var lblMonthlyEarnings: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func calculateSalary() {
        guard let totalSalary = Double(txtSalary.text ?? ""),
              let dailyWorkingHours = Double(txtDailyWorkingHours.text ?? ""),
              let totalDaysInMonth = Double(txtDaysInThisMonth.text ?? ""),
              let workedDays = Double(txtWorksDays.text ?? ""),
              totalDaysInMonth > 0, workedDays > 0, dailyWorkingHours > 0 else {
            print("Invalid input")
            return
        }
        
        let totalHoursInMonth = dailyWorkingHours * totalDaysInMonth
        let totalHoursWorked = dailyWorkingHours * workedDays
        
        // Avoid division by zero
        if totalHoursInMonth == 0 || totalHoursWorked == 0 {
            print("Total hours in month or worked cannot be zero")
            return
        }
        
        let takeHomeSalary = (totalSalary / totalHoursInMonth) * totalHoursWorked
        
        let perDaySalary = takeHomeSalary / workedDays
        let perHourSalary = takeHomeSalary / totalHoursWorked
        let perMinSalary = perHourSalary / 60
        
        lblMonthlyEarnings.text = "Per Month: " + String(format: "%.2f", takeHomeSalary)
        lblPerDaySalary.text = "Per Day: " + String(format: "%.2f", perDaySalary)
        lblPerHourSalary.text = "Per Hour: " + String(format: "%.2f", perHourSalary)
        lblPerMinSalary.text = "Per Min: " + String(format: "%.2f", perMinSalary)
    }

    @IBAction func onBtnCalculate(_ sender: Any) {
        view.endEditing(true)
        calculateSalary()
    }
    
}

