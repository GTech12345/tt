//
//  DropVC.swift
//  Office
//
//  Created by Milan B. Savaliya on 23/10/24.
//

import UIKit

class DropVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDragDelegate, UICollectionViewDropDelegate {

    var items: [String] = ["a", "b", "c", "d", "e"]

    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .white
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.dragDelegate = self
        collectionView.dropDelegate = self
        collectionView.dragInteractionEnabled = true // Enable drag interaction
        
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        return collectionView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(collectionView)
        collectionView.frame = view.bounds
    }

    // MARK: - UICollectionView DataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        cell.backgroundColor = .lightGray
        
        // Configure the label in the cell
        let label = UILabel(frame: cell.contentView.frame)
        label.text = items[indexPath.item]
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 20)
        
        cell.contentView.subviews.forEach { $0.removeFromSuperview() } // Clear any old views
        cell.contentView.addSubview(label)
        return cell
    }

    // MARK: - UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Create 3 columns
        let padding: CGFloat = 30 // Total padding between cells
        let cellWidth = (collectionView.frame.width - padding) / 3 // Divide width by 3 for 3 columns
        return CGSize(width: cellWidth, height: cellWidth)
    }

    // MARK: - UICollectionViewDragDelegate
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        let item = items[indexPath.item]
        let itemProvider = NSItemProvider(object: item as NSString)
        let dragItem = UIDragItem(itemProvider: itemProvider)
        dragItem.localObject = item // Local object for reordering
        return [dragItem]
    }

    // MARK: - UICollectionViewDropDelegate
    func collectionView(_ collectionView: UICollectionView, performDropWith coordinator: UICollectionViewDropCoordinator) {
        guard let destinationIndexPath = coordinator.destinationIndexPath else {
            return
        }

        if coordinator.proposal.operation == .move {
            guard let dragItem = coordinator.items.first, let sourceIndexPath = dragItem.sourceIndexPath else {
                return
            }

            if sourceIndexPath != destinationIndexPath {
                collectionView.performBatchUpdates({
                    let itemToMove = items.remove(at: sourceIndexPath.item)
                    items.insert(itemToMove, at: destinationIndexPath.item)

                    collectionView.moveItem(at: sourceIndexPath, to: destinationIndexPath)
                }, completion: nil)

                coordinator.drop(dragItem.dragItem, toItemAt: destinationIndexPath)
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, canHandle session: UIDropSession) -> Bool {
        return session.canLoadObjects(ofClass: NSString.self)
    }

    func collectionView(_ collectionView: UICollectionView, dropSessionDidUpdate session: UIDropSession, withDestinationIndexPath destinationIndexPath: IndexPath?) -> UICollectionViewDropProposal {
        return UICollectionViewDropProposal(operation: .move, intent: .insertAtDestinationIndexPath)
    }
}
