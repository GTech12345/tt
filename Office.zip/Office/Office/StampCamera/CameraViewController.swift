//
// CameraViewController.swift
// Office
//
// Created by Milan B. Savaliya on 19/09/24.
//
import AVFoundation
import UIKit
import Photos
var overlayView: UIView?
class CameraViewController: UIViewController, AVCapturePhotoCaptureDelegate {
    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var captureButton: UIButton!
    @IBOutlet weak var toggleCameraButton: UIButton!
    @IBOutlet weak var toggleFlashButton: UIButton!
    @IBOutlet weak var lensButton: UIButton!
    let captureSession = AVCaptureSession()
    let photoOutput = AVCapturePhotoOutput()
    var previewLayer: AVCaptureVideoPreviewLayer!
    var captureDevice: AVCaptureDevice!
    var flashMode = AVCaptureDevice.FlashMode.off
    var currentCameraIndex = 0
    var cameras: [AVCaptureDevice] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            DispatchQueue.main.async {
                if granted {
                    self?.setupCaptureSession()
                    self?.setupPreviewLayer()
                    self?.setupCaptureButton()
                    self?.setupToggleCameraButton()
                    self?.setupToggleFlashButton()
                    self?.setupLensButton()
                    DispatchQueue.global(qos: .userInitiated).async {
                        self?.captureSession.startRunning()
                    }
                } else {
                    print("Camera access denied")
                }
            }
        }
    }
    func loadXIB() {
        if let overlayNib = Bundle.main.loadNibNamed("TestView", owner: self, options: nil)?.first as? UIView {
            overlayView = overlayNib
            updateOverlayFrame()
            previewView.addSubview(overlayView!)
            let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
            overlayView?.addGestureRecognizer(panGesture)
        }
    }
    @objc func handlePanGesture(_ gestureRecognizer: UIPanGestureRecognizer) {
        guard let view = gestureRecognizer.view else { return }
        let translation = gestureRecognizer.translation(in: previewView)
        var newCenter = CGPoint(x: view.center.x + translation.x, y: view.center.y + translation.y)
        let halfWidth = view.bounds.width / 2
        let halfHeight = view.bounds.height / 2
        newCenter.x = max(halfWidth, min(previewView.bounds.width - halfWidth, newCenter.x))
        newCenter.y = max(halfHeight, min(previewView.bounds.height - halfHeight, newCenter.y))
        view.center = newCenter
        gestureRecognizer.setTranslation(.zero, in: previewView)
    }
    func updateOverlayFrame() {
        let previewWidth = previewView.bounds.width
        let previewHeight = previewView.bounds.height
        let aspectRatio: CGFloat = 16.0 / 9.0
        var overlayWidth = previewWidth * 0.9
        var overlayHeight = overlayWidth / aspectRatio
        if overlayHeight > previewHeight {
            overlayHeight = previewHeight * 0.9
            overlayWidth = overlayHeight * aspectRatio
        }
        overlayView?.frame = CGRect(x: (previewWidth - overlayWidth) / 2,
                                    y: (previewHeight - overlayHeight) / 2,
                                    width: overlayWidth,
                                    height: overlayHeight)
    }
    func setupCaptureSession() {
        captureSession.beginConfiguration()
        cameras = [AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)!]
        if let ultraWideAngleCamera = AVCaptureDevice.default(.builtInUltraWideCamera, for: .video, position: .back) {
            cameras.append(ultraWideAngleCamera)
        }
        if let telephotoCamera = AVCaptureDevice.default(.builtInTelephotoCamera, for: .video, position: .back) {
            cameras.append(telephotoCamera)
        }
        if cameras.count == 1 {
            lensButton.isHidden = true
        }
        self.captureDevice = cameras[currentCameraIndex]
        guard let captureInput = try? AVCaptureDeviceInput(device: captureDevice) else {
            print("Failed to create capture input")
            return
        }
        captureSession.addInput(captureInput)
        if captureSession.canAddOutput(photoOutput) {
            captureSession.addOutput(photoOutput)
        }
        captureSession.commitConfiguration()
        setLensTitle()
    }
    func setupPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.frame = previewView.bounds
        previewView.layer.addSublayer(previewLayer)
        loadXIB()
    }
    func setupCaptureButton() {
        captureButton.addTarget(self, action: #selector(capturePhoto), for: .touchUpInside)
    }
    func setupToggleCameraButton() {
        toggleCameraButton.addTarget(self, action: #selector(toggleCamera), for: .touchUpInside)
    }
    func setupToggleFlashButton() {
        toggleFlashButton.addTarget(self, action: #selector(toggleFlash), for: .touchUpInside)
    }
    func setupLensButton() {
        lensButton.addTarget(self, action: #selector(switchLens), for: .touchUpInside)
    }
    func setLensTitle() {
        if let camera = captureDevice {
            var lensTitle = ""
            if camera.deviceType == .builtInUltraWideCamera {
                lensTitle = "0.5x"
            } else if camera.deviceType == .builtInWideAngleCamera {
                lensTitle = "1x"
            } else if camera.deviceType == .builtInTelephotoCamera {
                lensTitle = "2x"
            }
            lensButton.setTitle(lensTitle, for: .normal)
        }
    }
    @objc func capturePhoto() {
        let settings = AVCapturePhotoSettings()
        settings.flashMode = flashMode
        photoOutput.capturePhoto(with: settings, delegate: self)
    }
    @objc func toggleCamera() {
        let currentPosition = captureDevice.position
        let newPosition: AVCaptureDevice.Position = currentPosition == .front ? .back : .front
        guard let newCaptureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: newPosition) else {
            print("Failed to get the camera device")
            return
        }
        captureDevice = newCaptureDevice
        captureSession.beginConfiguration()
        guard let currentInput = captureSession.inputs.first as? AVCaptureDeviceInput,
              let newInput = try? AVCaptureDeviceInput(device: newCaptureDevice) else {
            captureSession.commitConfiguration()
            return
        }
        captureSession.removeInput(currentInput)
        captureSession.addInput(newInput)
        captureSession.commitConfiguration()
        lensButton.isHidden = newPosition == .front
        setLensTitle()
    }
    @objc func toggleFlash() {
        flashMode = flashMode == .off ? .on : .off
        toggleFlashButton.isSelected = flashMode == .on
    }
    @objc func switchLens() {
        currentCameraIndex = (currentCameraIndex + 1) % cameras.count
        captureSession.beginConfiguration()
        guard let captureInput = try? AVCaptureDeviceInput(device: cameras[currentCameraIndex]) else {
            return
        }
        captureSession.removeInput(captureSession.inputs[0] as! AVCaptureDeviceInput)
        captureSession.addInput(captureInput)
        captureSession.commitConfiguration()
        setLensTitle()
    }
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            print("Error capturing photo: \(error)")
            return
        }
        guard let imageData = photo.fileDataRepresentation(),
              let cameraImage = UIImage(data: imageData) else {
            return
        }
        let overlayImage = overlayView?.asImage()
        let overlayFrameInPreview = overlayView?.frame ?? CGRect.zero
        if let finalImage = combineImages(backgroundImage: cameraImage, overlayImage: overlayImage, overlayFrame: overlayFrameInPreview) {
            self.saveImageToPhotosAlbum(image: finalImage)
        }
    }
    func saveImageToPhotosAlbum(image: UIImage) {
        PHPhotoLibrary.shared().performChanges({
            _ = PHAssetChangeRequest.creationRequestForAsset(from: image)
        }, completionHandler: { success, error in
            if let error = error {
                print("Error saving image: \(error.localizedDescription)")
            } else {
                print("Image saved successfully")
            }
        })
    }
    func combineImages(backgroundImage: UIImage, overlayImage: UIImage?, overlayFrame: CGRect) -> UIImage? {
        let screenSize = previewView.bounds.size
        let backgroundSize = backgroundImage.size
        let scaleX = backgroundSize.width / screenSize.width
        let scaleY = backgroundSize.height / screenSize.height
        let scaleFactor = min(scaleX, scaleY)
        let xOffset = (screenSize.width - backgroundSize.width / scaleFactor) / 2
        let yOffset = (screenSize.height - backgroundSize.height / scaleFactor) / 2
        let scaledOverlayFrame = CGRect(x: (overlayFrame.origin.x - xOffset) * scaleFactor,
                                        y: (overlayFrame.origin.y - yOffset) * scaleFactor,
                                        width: overlayFrame.width * scaleFactor,
                                        height: overlayFrame.height * scaleFactor)
        UIGraphicsBeginImageContextWithOptions(backgroundImage.size, false, 0.0)
        backgroundImage.draw(in: CGRect(origin: .zero, size: backgroundImage.size))
        if let overlayImage = overlayImage {
            overlayImage.draw(in: scaledOverlayFrame)
        }
        let combinedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return combinedImage
    }
}
extension UIView {
    func asImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}
