import UIKit

class SubscriptionVC: UIViewController {
    
    @IBOutlet weak var lblisFreeTrial: UILabel!
    @IBOutlet weak var isPurchase: UILabel!
    @IBOutlet weak var tblPlans: UITableView!
    @IBOutlet weak var currantPlan: UILabel!
    
    var subscriptionPlans: [SubscriptionPlan] = [] // To store subscription plans
    var currentActivePlan: String = "" // Store the current active plan identifier

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblPlans.register(.init(nibName: "PlanCell", bundle: nil), forCellReuseIdentifier: "PlanCell")
        tblPlans.dataSource = self
        tblPlans.delegate = self
        
        // Check for an active subscription
        checkActiveSubscription()
        
        // Fetch subscription plans
        fetchSubscriptionPlans()
    }
    
    /// Check for active subscriptions
    func checkActiveSubscription() {
        IAPHelper.shared.validateReceipt { result in
            switch result {
            case .success(let receipt):
                let activePlans = IAPHelper.shared.subscriptionProductIDs.filter { IAPHelper.shared.isSubscriptionActive(for: $0, receipt: receipt) }
                
                DispatchQueue.main.async {
                    if activePlans.isEmpty {
                        self.isPurchase.text = "No active subscription."
                        self.currantPlan.text = "Current Plan: None"
                        self.lblisFreeTrial.text = "Free trial not active"
                    } else {
                        self.isPurchase.text = "You have an active subscription."
                        // Update current active plan (you can customize this logic)
                        self.currentActivePlan = activePlans.first ?? ""
                        self.currantPlan.text = "Current Active Plan: \(self.currentActivePlan)"
                        
                        // Check if any of the active plans has a free trial
                        if activePlans.contains(where: { IAPHelper.shared.isFreeTrialActive(for: $0, receipt: receipt) }) {
                            self.lblisFreeTrial.text = "You are currently on a free trial."
                        } else {
                            self.lblisFreeTrial.text = "Free trial not active"
                        }
                    }
                }
                
            case .failure(let error):
                DispatchQueue.main.async {
                    self.isPurchase.text = "Failed to validate receipt: \(error.localizedDescription)"
                }
            }
        }
    }
    
    /// Fetch subscription plans using IAPHelper
    func fetchSubscriptionPlans() {
        IAPHelper.shared.getSubscriptionPlans { plans in
            print(plans)
            DispatchQueue.main.async {
                self.subscriptionPlans = plans
                self.tblPlans.reloadData()
            }
        }
    }
    
    /// Handle purchase success
    func handlePurchaseSuccess() {
        self.isPurchase.text = "Purchase successful!"
        // Reload active subscription info
        checkActiveSubscription()
    }
    
    /// Handle purchase failure
    func handlePurchaseFailure(error: Error) {
        self.isPurchase.text = "Purchase failed: \(error.localizedDescription)"
    }
    
    @IBAction func restorePurchasesTapped(_ sender: UIButton) {
        IAPHelper.shared.restorePurchases { success in
            if success {
                self.isPurchase.text = "Purchases restored successfully!"
                // Reload active subscription info
                self.checkActiveSubscription()
            } else {
                self.isPurchase.text = "No purchases to restore."
            }
        }
    }
}

extension SubscriptionVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return subscriptionPlans.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlanCell", for: indexPath) as! PlanCell
        
        let plan = subscriptionPlans[indexPath.row]
        
        // Configure cell with subscription plan details
        cell.planTitle.text = "Title: \(plan.title)"
        cell.planPrice.text = "Plan Price: \(plan.price)"
        cell.planId.text = "Plan Id: \(plan.productId)"
        cell.isFreeTrialAvailabel.text = "is Free Trial Available: \(plan.isFreeTrialAvailable)"
        
        if plan.isFreeTrialAvailable {
            cell.lblFreeTrialDays.text = "\(plan.trialDescription)"
        } else {
            cell.lblFreeTrialDays.text = "Free trial not active"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedPlan = subscriptionPlans[indexPath.row]

        IAPHelper.shared.purchaseProduct(productId: selectedPlan.productId) { result in
            switch result {
            case .success:
                self.handlePurchaseSuccess()
            case .failure(let error):
                self.handlePurchaseFailure(error: error)
            }
        }
    }
}
