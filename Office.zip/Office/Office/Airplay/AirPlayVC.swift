//
//  AirPlayVC.swift
//  Office
//
//  Created by Milan B. Savaliya on 14/10/24.
//

import UIKit
import AVFoundation

class AirPlayVC: UIViewController {
    
    @IBOutlet weak var recordButton: UIButton!

    var audioEngine: AVAudioEngine!
    var inputNode: AVAudioInputNode!
    var outputNode: AVAudioOutputNode!
    var isRecording = false
    var audioFile: AVAudioFile!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupAudioSession()
        setupAudioEngine()
    }

    func setupAudioSession() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try audioSession.setActive(true)
        } catch {
            showAlert("Failed to set up audio session: \(error.localizedDescription)")
        }
    }

    func setupAudioEngine() {
        audioEngine = AVAudioEngine()
        inputNode = audioEngine.inputNode
        outputNode = audioEngine.outputNode
        
        // Get the hardware format of the input node
        let hwFormat = inputNode.outputFormat(forBus: 0)

        // Install a tap on the input node to process audio
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: hwFormat) { (buffer, time) in
            self.processAudioBuffer(buffer)
        }

        // Connect the input node to the output node
        audioEngine.connect(inputNode, to: outputNode, format: hwFormat)
    }

    @IBAction func recordButtonTapped(_ sender: UIButton) {
        if isRecording {
            stopRecording()
            recordButton.setTitle("Start Recording", for: .normal)
        } else {
            startRecording()
            recordButton.setTitle("Stop Recording", for: .normal)
        }
        isRecording.toggle()
    }

    func startRecording() {
        // Create the audio file to save the recording
        let audioFileURL = getAudioFileURL()
        do {
            audioFile = try AVAudioFile(forWriting: audioFileURL, settings: inputNode.outputFormat(forBus: 0).settings)
            audioEngine.prepare()
            try audioEngine.start()
        } catch {
            showAlert("Failed to start audio engine: \(error.localizedDescription)")
        }
    }

    func stopRecording() {
        audioEngine.stop()
        inputNode.removeTap(onBus: 0)
        audioFile = nil // Clear the reference to the audio file
    }

    func processAudioBuffer(_ buffer: AVAudioPCMBuffer) {
        // Write the audio buffer to the audio file
        do {
            if isRecording {
                try audioFile.write(from: buffer)
            }
        } catch {
            showAlert("Failed to write audio buffer: \(error.localizedDescription)")
        }
    }

    func getAudioFileURL() -> URL {
        let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documentDirectory.appendingPathComponent("recordedAudio.m4a")
    }

    func showAlert(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
