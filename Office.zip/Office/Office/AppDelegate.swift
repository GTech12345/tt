//
//  AppDelegate.swift
//  Office
//
//  Created by Milan B. Savaliya on 19/09/24.
//

import UIKit
import SwiftyStoreKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        setupSwiftyStoreKit()
    
        return true
    }

   
    func setupSwiftyStoreKit() {
        SwiftyStoreKit.completeTransactions(atomically: true) { purchases in
            for purchase in purchases {
                // Handle each purchase here (restore, update UI, etc.)
                switch purchase.transaction.transactionState {
                case .purchased:
                    // Unlock content for purchased item
                    print("Purchased: \(purchase)")
                case .restored:
                    // Restore content for restored item
                    print("Restored: \(purchase)")
                case .failed:
                    // Handle failed transactions
                    print("failed")
                  break
                default:
                    break
                }
            }
        }
    }


}

