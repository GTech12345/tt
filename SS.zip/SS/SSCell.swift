//
//  SSCell.swift
//  Office
//
//  Created by Milan B. Savaliya on 06/11/24.
//

import UIKit

class SSCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
