//
//  SSViewImageVC.swift
//  Office
//
//  Created by Milan B. Savaliya on 06/11/24.
//

import UIKit

class SSViewImageVC: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var img: UIImageView!
    
    var image: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the image to the UIImageView
         img.image = image
         
         // Set the content size of the scroll view to match the image size
         scrollView.contentSize = img.frame.size
         
         // Enable zooming on the scrollView
         scrollView.delegate = self
         scrollView.minimumZoomScale = 1.0  // Minimum zoom scale (no zoom)
         scrollView.maximumZoomScale = 100.0  // Maximum zoom scale (maximum zoom level)

         // Set the image view as the scroll view's zoom view
         scrollView.addSubview(img)
         
         // Adjust the imageView's frame to fit the scroll view
         img.frame = CGRect(x: 0, y: 0, width: scrollView.frame.width, height: scrollView.frame.height)
    }
    // UIScrollViewDelegate method to handle zooming
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return img  // The view that will be zoomed is the imageView
    }
}

