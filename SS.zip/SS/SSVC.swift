//
//  SSVC.swift
//  Office
//
//  Created by Milan B. Savaliya on 06/11/24.
//
//  pod "BSImagePicker", "~> 3.1"

import UIKit
import BSImagePicker
import Photos

class SSVC: UIViewController {
    
    @IBOutlet weak var clvView: UICollectionView!
    
    private var selectedImages: [UIImage] = []  // Store selected images
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        requestPhotoLibraryAccess()
        setupCollectionView()
    }
    
    private func setupCollectionView() {
        clvView.register(UINib(nibName: "SSCell", bundle: nil), forCellWithReuseIdentifier: "SSCell")
        clvView.delegate = self
        clvView.dataSource = self
    }
    
    private func requestPhotoLibraryAccess() {
        PHPhotoLibrary.requestAuthorization { status in
            switch status {
            case .authorized:
                print("Access granted to photo library.")
            case .denied, .restricted, .notDetermined:
                print("Access denied or restricted.")
            default:
                break
            }
        }
    }
    
    private func openPhotoPicker() {
//        let allAssets = PHAsset.fetchAssets(with: PHAssetMediaType.image, options: nil)
//        var evenAssets = [PHAsset]()

        let imagePicker = ImagePickerController()
        imagePicker.settings.fetch.assets.supportedMediaTypes = [.image]
//        imagePicker.settings.selection.max = 0
        imagePicker.settings.theme.selectionStyle = .checked
        
        self.presentImagePicker(imagePicker, select: { asset in
            print("Selected: \(asset)")
        }, deselect: { (asset) in
            print("Deselected: \(asset)")
        }, cancel: { (assets) in
            print("Canceled with selections: \(assets)")
        }, finish: { (assets) in
            print("Finished with selections: \(assets)")
            self.fetchImages(from: assets)
        })
    }
    
    private func fetchImages(from assets: [PHAsset]) {
        let imageManager = PHCachingImageManager()
        let requestOptions = PHImageRequestOptions()
        requestOptions.isSynchronous = false
        requestOptions.deliveryMode = .highQualityFormat

        selectedImages = []
        
        // Dispatch group to wait for all requests
        let dispatchGroup = DispatchGroup()
        
        for asset in assets {
            dispatchGroup.enter()  // Enter the dispatch group for each request
            
            // Get the original size of the asset
            let originalSize = CGSize(width: asset.pixelWidth, height: asset.pixelHeight)
            
            // Set a maximum width (or height) and calculate the aspect ratio
            let maxWidth: CGFloat = 1080
            let maxHeight: CGFloat = 1080
            let aspectRatio = originalSize.width / originalSize.height
            
            var targetSize: CGSize
            if aspectRatio > 1 {
                // Landscape: constrain by max width
                targetSize = CGSize(width: maxWidth, height: maxWidth / aspectRatio)
            } else {
                // Portrait: constrain by max height
                targetSize = CGSize(width: maxHeight * aspectRatio, height: maxHeight)
            }
            
            print("Original Size: \(originalSize), Target Size: \(targetSize)")
            
            // Request the image with the calculated target size
            imageManager.requestImage(for: asset, targetSize: targetSize, contentMode: .aspectFit, options: requestOptions) { [weak self] image, _ in
                if let image = image {
                    self?.selectedImages.append(image)
                }
                dispatchGroup.leave()  // Leave the dispatch group once the image is fetched
            }
        }
        
        // Reload collection view only once all images are loaded
        dispatchGroup.notify(queue: .main) {
            self.clvView.reloadData()
        }
    }
    
//    private func stitchImagesVertically(images: [UIImage], spacing: CGFloat) -> UIImage? {
//        guard !images.isEmpty else { return nil }
//        
//        // Calculate the total width (max width of any image) and total height
//        let maxImageWidth = images.max(by: { $0.size.width < $1.size.width })?.size.width ?? 0
//        let totalHeight = images.reduce(0) { $0 + $1.size.height } + spacing * CGFloat(images.count - 1)
//        
//        // Begin a graphics context with the max width and total height
//        UIGraphicsBeginImageContextWithOptions(CGSize(width: maxImageWidth, height: totalHeight), false, 0.0)
//        
//        // Draw each image into the context, maintaining its aspect ratio
//        var yOffset: CGFloat = 0
//        for image in images {
//            // Calculate the new width based on the image's aspect ratio
//            let aspectRatio = image.size.width / image.size.height
//            let targetHeight = image.size.height
//            let targetWidth = targetHeight * aspectRatio
//            
//            // Center the image horizontally if it is narrower than max width
//            let xOffset = (maxImageWidth - targetWidth) / 2
//            
//            // Draw the image in the context
//            image.draw(in: CGRect(x: xOffset, y: yOffset, width: targetWidth, height: targetHeight))
//            yOffset += targetHeight + spacing
//        }
//        
//        // Capture the combined image from the context
//        let stitchedImage = UIGraphicsGetImageFromCurrentImageContext()
//        UIGraphicsEndImageContext()
//        
//        return stitchedImage
//    }
    
    private func stitchImagesVertically(images: [UIImage], spacing: CGFloat) -> UIImage? {
        guard !images.isEmpty else { return nil }
        
        // Define a max width for downscaled images
        let maxImageWidth: CGFloat = UIScreen.main.bounds.width
        var totalHeight: CGFloat = 0
        
        // Calculate total height and downscale images
        var resizedImages: [UIImage] = []
        for image in images {
            let aspectRatio = image.size.width / image.size.height
            let targetWidth = min(image.size.width, maxImageWidth)  // Scale down if width exceeds max
            let targetHeight = targetWidth / aspectRatio
            totalHeight += targetHeight + spacing

            // Resize the image to target size
            UIGraphicsBeginImageContextWithOptions(CGSize(width: targetWidth, height: targetHeight), false, 0.0)
            image.draw(in: CGRect(origin: .zero, size: CGSize(width: targetWidth, height: targetHeight)))
            let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            if let resizedImage = resizedImage {
                resizedImages.append(resizedImage)
            }
        }
        totalHeight -= spacing  // Remove extra spacing after the last image

        // Begin final graphics context with total height
        UIGraphicsBeginImageContextWithOptions(CGSize(width: maxImageWidth, height: totalHeight), false, 0.0)
        
        // Draw each resized image into the context
        var yOffset: CGFloat = 0
        for image in resizedImages {
            image.draw(in: CGRect(x: 0, y: yOffset, width: image.size.width, height: image.size.height))
            yOffset += image.size.height + spacing
        }
        
        // Capture the combined image from the context
        let stitchedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return stitchedImage
    }



    
    @IBAction func onBtnSelectImages(_ sender: Any) {
        openPhotoPicker()
    }
    
    @IBAction func onBtnConvert(_ sender: Any) {
        DispatchQueue.global(qos: .userInitiated).async {
            if let stitchedImage = self.stitchImagesVertically(images: self.selectedImages, spacing: 10.0) {
                DispatchQueue.main.async {
                    let vc = UIStoryboard(name: "SS", bundle: nil).instantiateViewController(withIdentifier: "SSViewImageVC") as! SSViewImageVC
                    vc.image = stitchedImage
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                DispatchQueue.main.async {
                    print("No images to stitch.")
                }
            }
        }
        
//        let image = stitchImagesVertically(images: selectedImages, spacing: 10.0)
//        let vc = UIStoryboard(name: "SS", bundle: nil).instantiateViewController(withIdentifier: "SSViewImageVC") as! SSViewImageVC
//        vc.image = image
//        self.navigationController?.pushViewController(vc, animated: true)
    }
}


extension SSVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SSCell", for: indexPath) as! SSCell
        cell.img.image = selectedImages[indexPath.item]  // Assuming SSCell has an imageView
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Calculate cell width
        let itemsPerRow: CGFloat = 3
        let padding: CGFloat = 15
        let totalPadding = padding * (itemsPerRow + 1)  // Spacing on all sides
        let availableWidth = collectionView.frame.width - totalPadding
        let cellWidth = availableWidth / itemsPerRow
        
        return CGSize(width: Int(cellWidth), height: Int(cellWidth))  // Square cells
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)  // 15 points padding on all sides
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15  // Vertical spacing between rows
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 15  // Horizontal spacing between items
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let image = stitchImagesVertically(images: selectedImages, spacing: 10.0)
        let vc = UIStoryboard(name: "SS", bundle: nil).instantiateViewController(withIdentifier: "SSViewImageVC") as! SSViewImageVC
        vc.image = selectedImages[indexPath.item]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
